// ==============================================================================
// Proyecto: BA Protege+
// Componente: Frontend Mobile
// Archivo: index.js
// Descripción: Registro de la aplicación en el AppRegistry de React Native.
// ==============================================================================

import { AppRegistry } from 'react-native';
import App from './src/App.js';

AppRegistry.registerComponent('BAProtege', () => App);
