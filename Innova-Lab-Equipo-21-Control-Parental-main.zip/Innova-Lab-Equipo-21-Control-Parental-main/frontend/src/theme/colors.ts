// ==============================================================================
// Proyecto: BA Protege+
// Componente: Frontend Mobile (Design System)
// Archivo: src/theme/colors.ts
// Descripción: Paleta de colores institucional, temas oscuros y tokens de diseño.
// ==============================================================================

export const colors = {
  // Colores principales e institucionales
  primary: '#0D6EFD',
  primaryDark: '#0A58CA',
  primaryLight: '#E7F1FF',

  // Estados de protección
  statusActive: '#198754',
  statusActiveBg: '#D1E7DD',
  statusInactive: '#6C757D',
  statusInactiveBg: '#E2E3E5',
  statusWarning: '#FFC107',
  statusWarningBg: '#FFF3CD',
  statusDanger: '#DC3545',
  statusDangerBg: '#F8D7DA',

  // Fondos y superficies
  background: '#F8F9FA',
  surface: '#FFFFFF',
  surfaceCard: '#FFFFFF',

  // Textos y contrastes
  textPrimary: '#212529',
  textSecondary: '#6C757D',
  textMuted: '#ADB5BD',
  textLight: '#FFFFFF',

  // Bordes y divisores
  border: '#DEE2E6',
  borderLight: '#E9ECEF',
};
